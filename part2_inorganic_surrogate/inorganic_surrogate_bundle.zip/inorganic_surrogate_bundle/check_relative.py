import sys, math
import numpy as np
sys.path.insert(0, '/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/nb_val_test1/aiomfac-python/tools')
sys.path.insert(0, '/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/inorganic_surrogate')
from closed_form_pipeline import make_samples, solve_bisulfate_closed_form, HERE
from train_mlp_benchmark import IN_COLS, OUT_COLS, load_and_split, train
import torch, pandas as pd

data_path = HERE / "training_data.parquet"
df_train, df_interp, df_gen = load_and_split(data_path)
model, scaler, maes, best_val = train(df_train, df_interp, df_gen)

samples = make_samples(300, seed=0)
mu, sd = scaler
df_in = pd.DataFrame([s["mlp_input_row"] for s in samples])
X = np.log1p(df_in[IN_COLS[:-1]].to_numpy(dtype=np.float32))
X = np.concatenate([X, df_in[["T_K"]].to_numpy(dtype=np.float32)], axis=1)
Xs = (X - mu) / sd
with torch.no_grad():
    pred = model(torch.from_numpy(Xs)).numpy()
i_h, i_hso4, i_so4 = OUT_COLS.index("ln_gamma_H+"), OUT_COLS.index("ln_gamma_HSO4-"), OUT_COLS.index("ln_gamma_SO4--")

rel_errs = []
abs_errs = []
scales = []
for k, s in enumerate(samples):
    gh_p, ghso4_p, gso4_p = math.exp(pred[k, i_h]), math.exp(pred[k, i_hso4]), math.exp(pred[k, i_so4])
    scale = s["m_h_max"] + s["m_sulf_max"]
    _, m_hso4_3pred, _ = solve_bisulfate_closed_form(s["m_h_max"], s["m_sulf_max"], s["T_K"], gh_p, ghso4_p, gso4_p)
    e = abs(m_hso4_3pred - s["m_hso4_true"])
    abs_errs.append(e)
    rel_errs.append(e / scale)
    scales.append(scale)

abs_errs = np.array(abs_errs); rel_errs = np.array(rel_errs); scales = np.array(scales)
print("abs MAE:", abs_errs.mean())
print("relative MAE (err / (m_h_max+m_sulf_max)):", rel_errs.mean(), "median:", np.median(rel_errs))
print("90th pct relative err:", np.percentile(rel_errs, 90))
print("scale range: ", scales.min(), scales.max())
# bucket by scale decile
order = np.argsort(scales)
for lo in range(0, 300, 100):
    idx = order[lo:lo+100]
    print(f"scale decile {lo}-{lo+100}: mean scale={scales[idx].mean():.4f} abs_err={abs_errs[idx].mean():.4e} rel_err={rel_errs[idx].mean():.4e}")
