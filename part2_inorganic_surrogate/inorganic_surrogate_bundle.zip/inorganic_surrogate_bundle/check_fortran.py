import sys, math
sys.path.insert(0, '/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/nb_val_test1/aiomfac-python/tests')
sys.path.insert(0, '/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/inorganic_surrogate')
from reference_utils import REF, parse_dump
from aiomfac_py import ActivityModel, read_input_file
from closed_form_pipeline import solve_bisulfate_closed_form

D = REF / 'carb_sulf'
case = read_input_file(D / 'inputs' / 'input_c005.txt')
pts = parse_dump(D / 'dumps' / 'debug_terms_c005.txt.gz')
model = ActivityModel(case.components)
idx_h, idx_oh, idx_hco3, idx_carb, idx_hso4, idx_so4, co2_idx, idx_ca = model._carb_sulf

hdr = "pt   T_K    m_H_true   m_HSO4_true  m_SO4_true  m_HSO4_pred  abs_err"
print(hdr)
errs = []
for k, p in enumerate(pts):
    T_K = float(case.T_K[k])
    m_h = p['SMC'][idx_h]; m_hso4 = p['SMA'][idx_hso4]; m_so4 = p['SMA'][idx_so4]
    lg_h = p['lnactcoeff_c'][idx_h]; lg_hso4 = p['lnactcoeff_a'][idx_hso4]; lg_so4 = p['lnactcoeff_a'][idx_so4]
    m_h_max = m_h + m_hso4
    m_sulf_max = m_so4 + m_hso4
    gh, ghso4, gso4 = math.exp(lg_h), math.exp(lg_hso4), math.exp(lg_so4)
    _, m_hso4_pred, _ = solve_bisulfate_closed_form(m_h_max, m_sulf_max, T_K, gh, ghso4, gso4)
    err = abs(m_hso4_pred - m_hso4)
    errs.append(err)
    print(k+1, T_K, m_h, m_hso4, m_so4, m_hso4_pred, err)
print('max', max(errs), 'mean', sum(errs)/len(errs))
