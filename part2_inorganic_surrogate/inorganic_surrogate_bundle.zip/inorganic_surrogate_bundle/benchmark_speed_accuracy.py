"""
Step 5 of the inorganic-aerosol-surrogate roadmap: speed/accuracy benchmark.

Mirrors the organic-surrogate paper's §3.9-3.10: compare AIOMFAC's direct Fortran-ported computation
against the MLP surrogate on wall-clock time, at the accuracy levels already measured in Steps 3-4.

Two scenarios, because aiomfac_py's own cost has two very different regimes:

  (a) FIXED SYSTEM, varying composition/T -- the common case in a box/column model integrating one
      fixed set of species over many timesteps/grid cells. ActivityModel(components) is built ONCE;
      only .evaluate() is timed per point. This is the cheap regime for aiomfac_py itself.

  (b) VARYING ION COMBINATION per point -- the Monte-Carlo / GSA / learning-pipeline case (e.g. each
      point is a randomly-drawn salt mixture, as in Step 2's data generator). Every point pays BOTH
      ActivityModel(components) construction (species list parsing, completion.py's dissociation/
      precipitation auto-wiring) AND .evaluate(). This is aiomfac_py's expensive regime, and the one
      a surrogate is actually meant to replace: the MLP takes the same fixed 15-dim input vector
      regardless of which ions are present (zeros for absent ones), so it pays no equivalent
      reconstruction cost per point.

The MLP is timed as a single batched forward pass (its natural usage mode), both on CPU (this
environment's only option) -- batch size swept from 1 to 10,000 to show where vectorization pays off.
"""
from __future__ import annotations

import sys
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import torch

HERE = Path(__file__).parent
AIOMFAC_SRC = Path("/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/nb_val_test1/aiomfac-python")
sys.path.insert(0, str(AIOMFAC_SRC / "tools"))
sys.path.insert(0, str(HERE))

from aiomfac_py import ActivityModel  # noqa: E402
from aiomfac_py.io import Component  # noqa: E402
from inorganic_component_basis import SOLVENT, CATIONS, ANIONS  # noqa: E402
from train_mlp_benchmark import IN_COLS, OUT_COLS, load_and_split, train  # noqa: E402

CATION_NAMES = [n for n, _, _ in CATIONS]
ANION_NAMES = [n for n, _, _ in ANIONS]
ION_SUB = {n: s for n, s, _ in CATIONS} | {n: s for n, s, _ in ANIONS}
ION_Z = {n: z for n, _, z in CATIONS} | {n: z for n, _, z in ANIONS}
torch.set_num_threads(1)  # fair single-core comparison; aiomfac_py's pure-Python/numpy path is single-core too


def _salt_stoich(z_cat: int, z_an: int) -> tuple[int, int]:
    import math
    g = math.gcd(abs(z_cat), abs(z_an))
    return abs(z_an) // g, abs(z_cat) // g


def random_combo(rng: np.random.Generator):
    n_cat, n_an = rng.integers(1, 3), rng.integers(1, 3)
    cats = rng.choice(CATION_NAMES, size=n_cat, replace=False)
    ans = rng.choice(ANION_NAMES, size=n_an, replace=False)
    water = Component(1, "Water", ((SOLVENT["subgroup"], 1),))
    comps = [water]
    fracs = []
    k = 2
    for cat in cats:
        for an in ans:
            qc, qa = _salt_stoich(ION_Z[cat], ION_Z[an])
            comps.append(Component(k, f"{cat}{an}", ((ION_SUB[cat], qc), (ION_SUB[an], qa))))
            fracs.append(float(10 ** rng.uniform(-3, -0.5)) * 0.05)  # small mass fraction, arbitrary
            k += 1
    T_K = float(rng.uniform(275.0, 325.0))
    return comps, fracs, T_K


# ---------------------------------------------------------------------------
# (a) fixed system, repeated evaluate()
# ---------------------------------------------------------------------------

def bench_fixed_system(n_points: int) -> float:
    water = Component(1, "Water", ((SOLVENT["subgroup"], 1),))
    salt = Component(2, "NaCl", ((202, 1), (242, 1)))
    model = ActivityModel([water, salt])      # built once
    rng = np.random.default_rng(0)
    fracs = rng.uniform(0.001, 0.2, size=n_points)
    Ts = rng.uniform(275.0, 325.0, size=n_points)
    t0 = time.perf_counter()
    for f, T in zip(fracs, Ts):
        model.evaluate([0.0, float(f)], float(T), basis="mass")
    return time.perf_counter() - t0


# ---------------------------------------------------------------------------
# (b) varying ion combination, full construct + evaluate per point
# ---------------------------------------------------------------------------

def bench_varying_combo(n_points: int, seed: int = 0) -> tuple[float, list]:
    # A tiny fraction (~0.02% at n=10000, seed=1) of randomly drawn combos land on a genuine numerical
    # edge case in aiomfac_py's carbonate/mr modules -- e.g. NH4+ paired with HCO3-/CO3--/OH- at low
    # concentration, where the ammonia-carbonate/hydroxide equilibrium drives a free-ion concentration to
    # ~0 and the dissociation solver divides by it. This is a real (if rare) corner case of the underlying
    # library, not a bug in this benchmark; it's irrelevant to what's being measured here (wall-clock time,
    # not accuracy), so the resulting RuntimeWarnings are suppressed rather than left to spam the output.
    # The wall-clock time for that point is still counted normally (it may run slightly slower).
    rng = np.random.default_rng(seed)
    samples = [random_combo(rng) for _ in range(n_points)]
    t0 = time.perf_counter()
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore", RuntimeWarning)
        for comps, fracs, T_K in samples:
            model = ActivityModel(comps)      # rebuilt every point -- the realistic surrogate-replaces-this cost
            model.evaluate([0.0] + fracs, T_K, basis="mass")
    return time.perf_counter() - t0, samples


def samples_to_mlp_input(samples) -> np.ndarray:
    """Re-derive the same fixed 15-dim nominal-molality input vector the MLP expects, from each
    sample's (comps, fracs, T_K) -- mirrors generate_training_data.py's ion_totals bookkeeping."""
    from aiomfac_py.params import load_subgroup_params
    sg = load_subgroup_params()
    mw = {}
    for n, s, _ in CATIONS:
        mw[n] = float(sg.SMWC[s - 201]) * 1e-3
    for n, s, _ in ANIONS:
        mw[n] = float(sg.SMWA[s - 241]) * 1e-3
    sub_to_name = {s: n for n, s, _ in CATIONS + ANIONS}
    rows = []
    for comps, fracs, T_K in samples:
        row = {c: 0.0 for c in IN_COLS}
        for comp, mass_frac in zip(comps[1:], fracs):
            # mass_frac here is the salt's mass fraction (kg salt / kg total) -- convert back to molal
            salt_mw = sum(mw[sub_to_name[sub]] * q for sub, q in comp.subgroups)
            molal = mass_frac / salt_mw  # approx (ignoring total-mass correction, fine for a speed/shape test)
            for sub, q in comp.subgroups:
                name = sub_to_name[sub]
                row[f"m_{name}"] += molal * q
        row["T_K"] = T_K
        rows.append(row)
    return pd.DataFrame(rows)


def bench_mlp_forward(model, scaler, df_in: pd.DataFrame) -> float:
    mu, sd = scaler
    X = np.log1p(df_in[IN_COLS[:-1]].to_numpy(dtype=np.float32))
    X = np.concatenate([X, df_in[["T_K"]].to_numpy(dtype=np.float32)], axis=1)
    Xs = (X - mu) / sd
    Xt = torch.from_numpy(Xs)
    t0 = time.perf_counter()
    with torch.no_grad():
        model(Xt)
    return time.perf_counter() - t0


def extract_numpy_weights(model) -> list[tuple[np.ndarray, np.ndarray]]:
    """Pull (W, b) pairs out of the trained torch MLP's nn.Linear layers, in order -- mirrors the
    organic-surrogate paper's deployment comparison of a framework-free numpy forward pass against the
    full torch model (no autograd/graph bookkeeping, no python-level nn.Module dispatch per layer)."""
    layers = [m for m in model.net if isinstance(m, torch.nn.Linear)]
    return [(l.weight.detach().numpy().astype(np.float32).T, l.bias.detach().numpy().astype(np.float32))
            for l in layers]


def numpy_mlp_forward(weights: list[tuple[np.ndarray, np.ndarray]], X: np.ndarray) -> np.ndarray:
    h = X
    for i, (W, b) in enumerate(weights):
        h = h @ W + b
        if i < len(weights) - 1:       # ReLU on every hidden layer, not the output layer
            np.maximum(h, 0.0, out=h)
    return h


def bench_numpy_forward(weights, scaler, df_in: pd.DataFrame) -> float:
    mu, sd = scaler
    X = np.log1p(df_in[IN_COLS[:-1]].to_numpy(dtype=np.float32))
    X = np.concatenate([X, df_in[["T_K"]].to_numpy(dtype=np.float32)], axis=1)
    Xs = ((X - mu) / sd).astype(np.float32)
    t0 = time.perf_counter()
    numpy_mlp_forward(weights, Xs)
    return time.perf_counter() - t0


def main():
    print("=== Step 5: speed/accuracy benchmark ===\n")

    print("-- (a) fixed system (NaCl), AIOMFAC repeated evaluate() only (model built once) --")
    for n in (1, 10, 100, 1000, 10000):
        t = bench_fixed_system(n)
        print(f"  n={n:6d}  total={t*1e3:9.2f} ms  per-point={t/n*1e6:9.2f} us")

    print("\n-- training MLP (re-using Step 3/4 setup) --")
    data_path = HERE / "training_data.parquet"
    df_train, df_interp, df_gen = load_and_split(data_path)
    model, scaler, maes, best_val = train(df_train, df_interp, df_gen)

    weights = extract_numpy_weights(model)
    # sanity: numpy forward must match torch forward (same weights, same math) to float32 precision
    df_check = samples_to_mlp_input([random_combo(np.random.default_rng(99)) for _ in range(20)])
    mu, sd = scaler
    Xc = np.log1p(df_check[IN_COLS[:-1]].to_numpy(dtype=np.float32))
    Xc = np.concatenate([Xc, df_check[["T_K"]].to_numpy(dtype=np.float32)], axis=1)
    Xc = ((Xc - mu) / sd).astype(np.float32)
    with torch.no_grad():
        y_torch = model(torch.from_numpy(Xc)).numpy()
    y_numpy = numpy_mlp_forward(weights, Xc)
    max_mismatch = np.abs(y_torch - y_numpy).max()
    print(f"\n(numpy-forward vs torch-forward sanity check: max|Δ|={max_mismatch:.2e}, should be ~1e-6 float32 noise)")

    print("\n-- (b) varying ion combination: AIOMFAC construct+evaluate per point  vs  MLP (torch) vs  MLP (pure numpy) --")
    print(f"  {'n':>6} {'AIOMFAC(ms)':>12} {'AIOMFAC/pt(us)':>15} {'torch(ms)':>10} {'torch/pt(us)':>13} "
          f"{'numpy(ms)':>10} {'numpy/pt(us)':>13} {'speedup(torch)':>15} {'speedup(numpy)':>15}")
    results = []
    for n in (1, 10, 100, 1000, 10000):
        t_direct, samples = bench_varying_combo(n, seed=1)
        df_in = samples_to_mlp_input(samples)
        t_mlp = bench_mlp_forward(model, scaler, df_in)
        t_np = bench_numpy_forward(weights, scaler, df_in)
        sp_torch = t_direct / t_mlp if t_mlp > 0 else float("inf")
        sp_numpy = t_direct / t_np if t_np > 0 else float("inf")
        results.append((n, t_direct, t_mlp, t_np, sp_torch, sp_numpy))
        print(f"  {n:6d} {t_direct*1e3:12.3f} {t_direct/n*1e6:15.2f} {t_mlp*1e3:10.3f} {t_mlp/n*1e6:13.2f} "
              f"{t_np*1e3:10.3f} {t_np/n*1e6:13.2f} {sp_torch:14.1f}x {sp_numpy:14.1f}x")

    print("\n-- GPU --")
    print(f"  torch.cuda.is_available() = {torch.cuda.is_available()}  "
          "-- no GPU in this environment; GPU-vs-CPU batched-forward comparison deferred to a follow-up"
          " notebook (organic-surrogate-paper style), as requested.")

    print("\n-- accuracy recap (from Steps 3-4, unchanged here) --")
    print("  MLP ln(gamma) MAE: train=0.054  interpolation=0.130  generalization=0.076  (natural-log units)")
    print("  Fortran cross-val (multi-salt + CaSO4(s) precip, Ca2+ excluded): MAE=0.165")
    print("  Step 4 closed-form derivation (H+/SO4--/HSO4- subsystem): oracle max err 1.9e-16 vs true Fortran"
          " SMC/SMA; surrogate-fed derived speciation relative MAE ~0.57% of the H+S(VI) pool scale")

    return results


if __name__ == "__main__":
    main()
