import sys
sys.path.insert(0, '/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/nb_val_test1/aiomfac-python/tools')
sys.path.insert(0, '/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/inorganic_surrogate')
from closed_form_pipeline import make_samples, oracle_check

for seed in (1, 2, 3):
    samples = make_samples(300, seed=seed)
    oracle_check(samples)
