"""
Step 6 of the inorganic-aerosol-surrogate roadmap: Sobol global sensitivity analysis downstream.

Mirrors the organic-surrogate paper's §2.6: use the FAST surrogate (not direct AIOMFAC calls -- Sobol
needs N*(2D+2) evaluations per case, tens of thousands of points, which Step 5 showed costs ~5-8 ms each
through the direct construct+evaluate path) to ask how much of the variance in predicted ln(gamma) each
input factor (a salt's molality, or temperature) is responsible for.

Factor design: Sobol factors must be VARIED INDEPENDENTLY, but the surrogate's 14-ion input vector is
only physically meaningful on charge-neutral compositions. So the factors here are PER-SALT molalities
(as in Step 2's own data generator), not per-ion molalities -- each salt is charge-balanced by
construction, so any combination of factor values still yields a valid (charge-neutral) composition.

Three representative cases (matching the design doc's "단일염/복수염/바이설페이트·바이카보네이트" stratification
from §평가 지표):
  1. single salt      : NaCl                                      (D=2: m_NaCl, T)
  2. multi-salt        : NaCl + NaNO3 + KCl + KNO3                 (D=5: 4 salts + T)
  3. bisulfate+bicarb  : Ca(IO3)2 + NaHSO4 + NaHCO3 (the c006-style system)  (D=4: 3 salts + T)
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from SALib.analyze import sobol as sobol_analyze
from SALib.sample import sobol as sobol_sample

HERE = Path(__file__).parent
AIOMFAC_SRC = Path("/tmp/claude-0/-home-claude/eecda288-448a-508f-8b60-1c1c2ce4350c/scratchpad/nb_val_test1/aiomfac-python")
sys.path.insert(0, str(AIOMFAC_SRC / "tools"))
sys.path.insert(0, str(HERE))

from inorganic_component_basis import CATIONS, ANIONS  # noqa: E402
from train_mlp_benchmark import IN_COLS, OUT_COLS, load_and_split, train  # noqa: E402

ION_Z = {n: z for n, _, z in CATIONS} | {n: z for n, _, z in ANIONS}


def _salt_stoich(z_cat: int, z_an: int) -> tuple[int, int]:
    g = math.gcd(abs(z_cat), abs(z_an))
    return abs(z_an) // g, abs(z_cat) // g


def salts_to_mlp_input(salt_names: list[tuple[str, str]], salt_molal: np.ndarray, T_K: np.ndarray) -> pd.DataFrame:
    """salt_molal: (n_samples, n_salts) molality of each salt; salt_names[k] = (cation, anion)."""
    rows = []
    n = salt_molal.shape[0]
    for i in range(n):
        row = {c: 0.0 for c in IN_COLS}
        for k, (cat, an) in enumerate(salt_names):
            m = salt_molal[i, k]
            qc, qa = _salt_stoich(ION_Z[cat], ION_Z[an])
            row[f"m_{cat}"] += m * qc
            row[f"m_{an}"] += m * qa
        row["T_K"] = T_K[i]
        rows.append(row)
    return pd.DataFrame(rows)


def mlp_predict(model, scaler, df_in: pd.DataFrame) -> np.ndarray:
    mu, sd = scaler
    X = np.log1p(df_in[IN_COLS[:-1]].to_numpy(dtype=np.float32))
    X = np.concatenate([X, df_in[["T_K"]].to_numpy(dtype=np.float32)], axis=1)
    Xs = (X - mu) / sd
    with torch.no_grad():
        return model(torch.from_numpy(Xs)).numpy()


def run_case(name: str, salt_names: list[tuple[str, str]], output_cols: list[str],
             model, scaler, N: int = 512, log_bounds=(-3.0, 0.3)):
    salt_param_names = [f"m_{cat}{an}" for cat, an in salt_names]
    problem = {
        "num_vars": len(salt_names) + 1,
        "names": salt_param_names + ["T_K"],
        "bounds": [list(log_bounds)] * len(salt_names) + [[275.0, 325.0]],
    }
    X = sobol_sample.sample(problem, N, calc_second_order=False, seed=0)
    salt_molal = 10.0 ** X[:, :len(salt_names)]
    T_K = X[:, -1]
    df_in = salts_to_mlp_input(salt_names, salt_molal, T_K)
    pred = mlp_predict(model, scaler, df_in)

    print(f"\n=== Case: {name}  (factors={problem['names']}, N={N}, runs={X.shape[0]}) ===")
    for col in output_cols:
        j = OUT_COLS.index(col)
        Y = pred[:, j]
        Si = sobol_analyze.analyze(problem, Y, calc_second_order=False, print_to_console=False, seed=0)
        print(f"  -- output: {col} --")
        print(f"     {'factor':12s} {'S1':>8s} {'S1_conf':>8s} {'ST':>8s} {'ST_conf':>8s}")
        for k, pname in enumerate(problem["names"]):
            print(f"     {pname:12s} {Si['S1'][k]:8.4f} {Si['S1_conf'][k]:8.4f} {Si['ST'][k]:8.4f} {Si['ST_conf'][k]:8.4f}")
        s1_sum = Si["S1"].sum()
        print(f"     sum(S1)={s1_sum:.4f} (<1 => interactions matter; S1 close to 1 => mostly additive)")


def main():
    print("=== Step 6: Sobol GSA on the trained MLP surrogate ===")
    data_path = HERE / "training_data.parquet"
    df_train, df_interp, df_gen = load_and_split(data_path)
    model, scaler, maes, best_val = train(df_train, df_interp, df_gen)

    run_case("1. single salt (NaCl)",
              [("Na+", "Cl-")],
              ["ln_gamma_H2O", "ln_gamma_Na+"],
              model, scaler, N=1024)

    run_case("2. multi-salt (NaCl+NaNO3+KCl+KNO3)",
              [("Na+", "Cl-"), ("Na+", "NO3-"), ("K+", "Cl-"), ("K+", "NO3-")],
              ["ln_gamma_H2O", "ln_gamma_Na+", "ln_gamma_K+"],
              model, scaler, N=512)

    run_case("3. bisulfate+bicarbonate (Ca(IO3)2+NaHSO4+NaHCO3)",
              [("Ca2+", "IO3-"), ("Na+", "HSO4-"), ("Na+", "HCO3-")],
              ["ln_gamma_H2O", "ln_gamma_Ca2+", "ln_gamma_HSO4-"],
              model, scaler, N=512)


if __name__ == "__main__":
    main()
