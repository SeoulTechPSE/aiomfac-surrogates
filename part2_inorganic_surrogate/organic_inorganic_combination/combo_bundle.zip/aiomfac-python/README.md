# aiomfac_py

Pure-Python port of the **AIOMFAC** thermodynamic group-contribution model (activity coefficients of
inorganic–organic mixtures). **Work in progress** — the activity-coefficient pipeline (LR + MR + SR and the
composition conversion) runs end-to-end, including the Fortran auto-completion and dissociation-equilibrium
machinery for bisulfate, bicarbonate, and joint bisulfate+bicarbonate systems (with Ca2+/CaSO4(s) precipitation);
see "Validation status" below for what is and isn't covered. `aiomfac_py.s2as` additionally integrates the
(already-Python) S2AS tool for going straight from a SMILES string to an AIOMFAC component.
`aiomfac_py.lle` adds a liquid-liquid equilibrium (LLE) solver built *on top of* `ActivityModel` -- a
from-scratch port of the primal-dual interior-point Gibbs-energy-minimization algorithm behind the UHAERO
aerosol model (Amundson et al., 2006, *J. Optim. Theory Appl.*, 130(3), 375-407), not part of AIOMFAC-web itself
and not Fortran-validated (see `src/aiomfac_py/lle.py`'s module docstring for what is and isn't faithful to that
paper, and `tests/test_lle.py` for how the solver itself, independent of AIOMFAC, is validated).

* Reference implementation: <https://github.com/andizuend/AIOMFAC> (AIOMFAC-web v3.14, commit
  `b9cb96d0eb22dc65a5e63edafe1ed97bd07662f2`). This port is validated against that Fortran code.
* `aiomfac_py.s2as` integrates <https://github.com/andizuend/S2AS__SMILES_to_AIOMFAC> (commit
  `88a2bffde1d375f8cb86a6e47ead6c3f0dad1833`) -- SMILES -> AIOMFAC subgroups, already pure Python upstream.
* `aiomfac_py.lle` ports the algorithm of Amundson, Caboussat, He & Seinfeld (2006), *J. Optim. Theory Appl.*,
  130(3), 375-407, doi:10.1007/s10957-006-9110-z -- an independent algorithm, not part of AIOMFAC-web, so this
  part of the package is not validated against the Fortran reference above.
* Scope of the first release: activity coefficients (plus LLE on top of them). The viscosity module
  (AIOMFAC-VISC, plus its organic-inorganic mixing extension) was added afterwards; see the
  `src/aiomfac_py/viscosity.py` row below for exactly what it covers.
* `aiomfac_py.tgml_armeli` loads the trained machine-learning Tg model of Armeli, Peters and Koop (2023,
  *ACS Omega* 8, 12298-12309) from the authors' own model files -- not part of AIOMFAC-web, and not a
  reimplementation of their model; see its own module docstring (`src/aiomfac_py/tgml_armeli/__init__.py`)
  and `PROVENANCE.md` next to it for exactly what was loaded, from where, and (for `PROVENANCE.md`) how the
  vendored pickle files were migrated so a modern `scikit-learn`/`numpy` can load them directly.
* License: **GPL-3.0-or-later**, because this is a derivative work of the (GPL-3.0) Fortran code (and, for
  `aiomfac_py.s2as`, of the GPL-3.0 S2AS tool). `aiomfac_py.tgml_armeli`'s vendored model files are a
  separate case -- see its `PROVENANCE.md` for their license status, which is unstated upstream.
* If you use it, please cite the AIOMFAC publications listed at <https://aiomfac.lab.mcgill.ca/citation.html>
  (and, for `aiomfac_py.s2as`, Amaladhasan et al., 2026, <https://doi.org/10.5194/gmd-19-4601-2026>), and (as
  requested by the authors) let them know about your use.

## Layout

| Path | Purpose |
|---|---|
| `src/aiomfac_py/io.py` | input-file reader (`read_input_file`) — done, tested |
| `src/aiomfac_py/params.py`, `data/*.npz` | SR (UNIFAC) tables R, Q, ARR, BRR, CRR and subgroup tables NKTAB, GroupMW, Ioncharge — extracted from the Fortran source, bit-identical to the arrays the compiled model uses |
| `src/aiomfac_py/system.py` | SR system setup (species/group ordering, R/Q, interaction matrix) — port of `SetSystem`/`SRsystm` parts |
| `src/aiomfac_py/sr.py` | **short-range term** (`sr_terms`) — validated against Fortran |
| `src/aiomfac_py/lr.py`, `mr.py` | long-range (Debye–Hückel) and middle-range terms, MR parameter mapping (`build_mr_state`) — validated |
| `src/aiomfac_py/composition.py`, `numerics.py` | mass/mole fraction → mass fraction → ion molalities; `safe_exp` — validated |
| `src/aiomfac_py/completion.py` | auto-completion of bisulfate/bicarbonate systems (species set) — validated structurally |
| `src/aiomfac_py/dissociation.py` | HSO4- <-> H+ + SO4-- equilibrium (Brent's method, `numerics.brent_root`) — validated end-to-end, wired into `ActivityModel` |
| `src/aiomfac_py/carbonate.py` | bicarbonate-only equilibrium (`solve_carbonate`, CO2(aq)/HCO3-/CO3--/OH-/H+, approximate ~1e-3 to 1e-4, see below) and the joint bisulfate+bicarbonate equilibrium (`solve_carb_sulf`, machine precision, plus Ca2+/CaSO4(s) precipitation) — both `scipy.optimize.root`-based, wired into `ActivityModel`; this is the carbonate/bicarbonate side of the ion extension of Yin et al. (2022, *Atmos. Chem. Phys.* 22, 973–1013) — the iodide/iodate (I-/IO3-) side of the same paper needs no dedicated module, just the existing ion subgroups and parameter tables, demonstrated in `notebooks/04_zuend2011_new_functional_groups.ipynb` |
| `src/aiomfac_py/model.py` | `ActivityModel` / `activity_coefficients()` — end-to-end for simple systems |
| `src/aiomfac_py/s2as/` | SMILES -> AIOMFAC subgroups (optional `epam.indigo` dependency) — integration of the upstream S2AS tool, validated bit-for-bit against it |
| `src/aiomfac_py/lle.py` | liquid-liquid equilibrium (`solve_pep`/`solve_pep_gfe`) — primal-dual interior-point/active-set Gibbs-energy minimization on top of `ActivityModel`, port of Amundson et al. (2006, JOTA 130); **not** part of AIOMFAC-web, not Fortran-validated (see the module docstring and `tests/test_lle.py`) |
| `src/aiomfac_py/gp_partition.py` | gas/particle partitioning at fixed RH (`gp_partition`) — joint Levenberg-Marquardt solver (default), a pseudo-transient RH-continuation fallback (inspired by Amundson et al., 2007, C. R. Acad. Sci.), and the original successive-substitution method, all on top of `ActivityModel`; **not** part of AIOMFAC-web (see the module docstring and `tests/test_gp_partition.py`) |
| `src/aiomfac_py/viscosity.py` | AIOMFAC-VISC (`electrolyte_viscosity`, `water_viscosity_pas`) — predictive dynamic-viscosity model for **aqueous electrolyte** solutions, port of Lilek and Zuend (2022, *Atmos. Chem. Phys.* 22, 3203–3233); built on top of `ActivityModel`'s ion molal activities/activity coefficients. Covers the 17 ions and all cation–anion pairs the paper fits. Also covers the paper's organic-inorganic mixing extension (Sect. 3): `organic_mixture_viscosity`/`pure_organic_viscosity_vtf` port the group-contribution organic-viscosity engine of Gervasi, Pye and Zuend (2020, *Atmos. Chem. Phys.* 20, 2987–3008); `aquelec_viscosity`/`aquorg_viscosity` implement two of Lilek and Zuend's three mixing rules (Sect. 3.4.1–3.4.2); and `predict_tg_derieux2018` implements the closed-form glass-transition-temperature estimate of DeRieux et al. (2018, *Atmos. Chem. Phys.* 18, 6331–6351) that the organic-viscosity model's Tg-dependent pure-component estimate relies on. Does **not** implement the ZSR mixing rule (Sect. 3.4.3, needs an iterative nonlinear solve) — see the module docstring and `tests/test_viscosity.py` |
| `src/aiomfac_py/tgml_armeli/` | `predict_tg_ml_fg`/`predict_tg_ml_smiles` — the newer, more accurate machine-learning Tg predictor of Armeli, Peters and Koop (2023, *ACS Omega* 8, 12298–12309; optional `tgml`/`tgml-smiles` dependencies). Not a reimplementation — loads the authors' own trained `scikit-learn` model files (`data/*.pkl`, from the paper's own Zenodo deposit, see `PROVENANCE.md`) directly, with no SMILES-featurization dependency on `deepchem`/`tensorflow` (confirmed unnecessary by reading `deepchem`'s own source, see `PROVENANCE.md`). Incidentally the same "TgML_Armeli" module the Fortran reference itself only ships as a separately-licensed, optional add-on (see the `smiles-based pure-component method?` note further down). Installs normally alongside the rest of this package (no separate environment needed) — the vendored pickle files were migrated (`tools/migrate_tgml_pickles.py`) so any reasonably current `scikit-learn` can load them directly, and SMILES-mode descriptors are looked up by name so any reasonably current `rdkit` works too (see `PROVENANCE.md` and the module docstring for the full story, including one small known accuracy caveat vs. the exact RDKit version A2023 trained on) |
| `tools/extract_params.py`, `tools/extract_mr_params.py` | regenerate `sr_params.npz`, `subgroup_params.npz`, `mr_params.npz` from the Fortran source (never edit tables by hand; `extract_mr_params` interprets `MRdata` statement by statement and reproduces Fortran literal kinds) |
| `fortran_patches/` | patch that makes the Fortran model dump every activity-coefficient term at full precision, plus notes on how to rebuild the references |
| `tests/reference/` | examples 0001/0003 (inputs, standard outputs, per-term dumps) |
| `tests/reference/cases/` | 9 generated validation cases, 145 points (`tools/make_cases.py` + `tools/run_fortran_cases.sh`) |
| `tests/reference/ext/` | 8 more generated cases, 106 points, targeting Qcca/Rcc, ester/ether/acid, aromatic/amine, PEG (`tools/make_cases_ext.py` + `tools/run_fortran_cases.sh`) |
| `tests/reference/completion/` | NaHSO4, NaHCO3 and H2SO4 cases: structural completion (`DIMS`) and, for the two bisulfate cases, the full dissociation-equilibrium pipeline |
| `tests/reference/carbonate/` | NaHCO3 and KHCO3 cases used to validate `carbonate.py`'s bicarbonate-only solve |
| `tests/reference/carb_sulf/` | NaHSO4+NaHCO3 (`c005`) and Ca(IO3)2+NaHSO4+NaHCO3 (`c006`) cases used to validate `carbonate.py`'s joint `solve_carb_sulf` and the Ca2+/CaSO4(s) precipitation step |
| `tests/reference/s2as/` | upstream S2AS's own 3 example SMILES lists (7, 174, and 2823 molecules) and their generated AIOMFAC input files, used to validate `s2as/` bit-for-bit |
| `fortran_patches/SubModDissociationEquil_carb_debug.f90` | throwaway-instrumented copy used once to dump Fortran's internal dissociation constants/converged molar amounts directly, for the per-species precision analysis above (not needed to use or test the package) |

## Conventions

* 0-based arrays; subgroup `s` ↔ index `s-1`, main group `g` ↔ index `g-1`; `ARR[i, j]` = Fortran `ARR(i+1, j+1)`.
* Species order (as in Fortran `X`): neutrals (input order), cations, anions.
* Composition tables: columns `cp02…cpNN` hold components 2..N; component 1 is `1 − Σ others`.

## Development

```
pip install -e .[test]
pytest
```
`test_port_matches_fortran` is a strict `xfail` today; when the port works it will start passing,
which pytest reports as a failure until the marker is removed — that is the signal to promote it to a real test.

## 🚀 Colab Quick Start (1 Cell)

`aiomfac_py` has no compiled dependencies of its own — pure Python + numpy, with two small optional extras
(`scipy` for the dissociation-equilibrium solvers, `epam.indigo` for the SMILES tool) — so, unlike
[SeoulTechPSE/fenicsx-colab](https://github.com/SeoulTechPSE/fenicsx-colab), there's no conda/micromamba
environment and no Jupyter cell magic here: a single `pip install` does it.

Open a new Google Colab notebook and run **this single cell**:

```python
# aiomfac_py on Google Colab
# SeoulTechPSE/aiomfac-python

from pathlib import Path
import subprocess

REPO_URL = "https://github.com/SeoulTechPSE/aiomfac-python.git"
REPO_DIR = Path("/content/aiomfac-python")

if not REPO_DIR.exists():
    print("Cloning aiomfac-python...")
    subprocess.run(["git", "clone", REPO_URL, str(REPO_DIR)], check=True)
else:
    print("Repository already exists — pulling latest...")
    subprocess.run(["git", "-C", str(REPO_DIR), "pull", "--ff-only"], check=True)

INSTALL_SMILES = False  # <-- set True to also install epam.indigo (aiomfac_py.s2as)
USE_CLEAN = False       # <-- set True to force a clean reinstall

opts = ["--carbonate"]
if INSTALL_SMILES:
    opts.append("--smiles")
if USE_CLEAN:
    opts.append("--clean")

get_ipython().run_line_magic("run", f"{REPO_DIR / 'setup_aiomfac.py'} {' '.join(opts)}")
```

After this finishes, `import aiomfac_py` works directly (installed editable, so files under `src/` can also be
edited and re-imported in the same Colab session without reinstalling).

See [`notebooks/bootstrap_colab.ipynb`](notebooks/bootstrap_colab.ipynb) for the same steps as a ready-to-run
notebook, [`notebooks/01_quickstart.ipynb`](notebooks/01_quickstart.ipynb) for four worked examples: reading
an AIOMFAC-web input file, building a mixture by hand (aqueous NaCl), the joint bisulfate+bicarbonate
dissociation equilibrium (with and without Ca2+ precipitation), and SMILES → AIOMFAC subgroups via
`aiomfac_py.s2as`; [`notebooks/02_reproduce_zuend2008.ipynb`](notebooks/02_reproduce_zuend2008.ipynb),
which reproduces (in style, not as a pixel-exact overlay) the activity-coefficient figures of the first
AIOMFAC journal paper, Zuend et al. (2008, *Atmos. Chem. Phys.*, doi:10.5194/acp-8-4559-2008) — binary and
quaternary electrolyte solutions, H2SO4/(NH4)2SO4 bisulfate dissociation, polyol+ammonium-sulfate ternaries,
salt+alcohol mean activity coefficients, and (using the new `aiomfac_py.lle` module) Fig. 9's NaCl-induced
liquid-liquid phase splitting; [`notebooks/03_zuend2010_lle.ipynb`](notebooks/03_zuend2010_lle.ipynb), which
reproduces Zuend et al. (2010, *Atmos. Chem. Phys.*, doi:10.5194/acp-10-7795-2010) — LLE phase diagrams and
stability maps (`aiomfac_py.lle`, `aiomfac_py.spinodal`) and RH-dependent gas/particle partitioning of a
six-component system (`aiomfac_py.gp_partition`, including a joint Levenberg-Marquardt solver that resolves a
genuine convergence failure of plain successive substitution for that system); and
[`notebooks/04_zuend2011_new_functional_groups.ipynb`](notebooks/04_zuend2011_new_functional_groups.ipynb),
which reproduces exemplary new-system calculations from the extended-parameterization paper, Zuend et al.
(2011, *Atmos. Chem. Phys.*, doi:10.5194/acp-11-9155-2011) — water activities of water + dicarboxylic acid +
(NH4)2SO4 systems (oxalic, malonic, succinic, glutaric acids), validated against the paper's own Appendix A2
measurements, demonstrating the new carboxyl functional group these systems require — plus a second section
reproducing new-ion systems (binary NaIO3/KIO3/HIO3, and NaI + dicarboxylic acid mixtures) from a later
extension paper, Yin et al. (2022, *Atmos. Chem. Phys.*, doi:10.5194/acp-22-973-2022), which adds the I-, IO3-,
HCO3-, CO3--, OH-, and CO2(aq) species (the carbonate/bicarbonate side of this extension was already covered by
`aiomfac_py.carbonate`; this section exercises the new iodide/iodate ion-organic interactions specifically);
and
[`notebooks/05_lilek_zuend2022_viscosity.ipynb`](notebooks/05_lilek_zuend2022_viscosity.ipynb), which uses the
`aiomfac_py.viscosity` module (AIOMFAC-VISC) to reproduce Fig. 4 of Lilek and Zuend (2022, *Atmos. Chem.
Phys.*, doi:10.5194/acp-22-3203-2022) — predicted viscosity vs. water mass fraction/activity for seven binary
aqueous chloride salts/acids (KCl, NaCl, LiCl, NH4Cl, MgCl2, HCl, CaCl2), reproducing the paper's
structure-breaking (K+, NH4+) vs. structure-making (Li+, Mg2+, Ca2+, H+) qualitative distinction, and then
extends into the paper's organic-inorganic mixing extension (Sect. 3): the organic-mixture viscosity engine
of Gervasi, Pye and Zuend (2020, *Atmos. Chem. Phys.*, doi:10.5194/acp-20-2987-2020) validated directly
against real CRC Handbook water+glycerol viscosity data (~2–8% agreement), the `aquelec`/`aquorg` mixing
rules demonstrated on a water+glycerol+NaCl ternary, and `predict_tg_derieux2018` (DeRieux et al., 2018,
*Atmos. Chem. Phys.*, doi:10.5194/acp-18-6331-2018) validated against that paper's own stachyose worked
example and shown, for glycerol, how much uncertainty a *predicted* (vs. measured) pure-component viscosity
adds to the mixture curve.

### Manual / local install

```
pip install "aiomfac_py[carbonate] @ git+https://github.com/SeoulTechPSE/aiomfac-python.git"
# or, from a local checkout:
python setup_aiomfac.py --carbonate          # see --help for --smiles / --all / --clean / --no-editable
```

## Usage

```python
from aiomfac_py import read_input_file, ActivityModel
case = read_input_file("tests/reference/inputs/input_0001.txt")
model = ActivityModel(case.components)
res = model.evaluate(case.fractions[0], case.T_K[0], case.basis)
res.gamma_neutral, res.ln_gamma          # activity coefficients / ln(gamma) of all species (neutrals, cations, anions)
```

Going straight from SMILES (requires the optional `epam.indigo` dependency: `pip install aiomfac_py[smiles]`):

```python
from aiomfac_py import ActivityModel
from aiomfac_py.s2as import smiles_to_components

result = smiles_to_components(["CCCCO"])         # 1-butanol; water is prepended automatically
model = ActivityModel(result.components)
res = model.evaluate([0.9, 0.1], 298.15, "mass")  # 90/10 mass-fraction water/butanol
```

Predicting Tg with the machine-learning model of Armeli, Peters and Koop (2023) -- install the `tgml`/
`tgml-smiles` extras normally, alongside the rest of this package:

```
pip install -e ".[tgml,tgml-smiles]"
```

```python
from aiomfac_py.tgml_armeli import predict_tg_ml_fg, predict_tg_ml_smiles

# Functional Group Mode: ethanol (CH3=1, CH2=1, OH=1, O:C=0.5, M=46.07 g/mol), no rdkit needed
predict_tg_ml_fg(1, 1, 0, 0, 1, 0, 0, 0, o_to_c=0.5, molar_mass_g_mol=46.07)   # TgMLResult(tg_K=..., ...)

# SMILES Mode (needs rdkit as well -- see module docstring for a small accuracy caveat vs. the exact RDKit
# version A2023 trained on, if you need byte-exact reproduction of their own reported numbers)
predict_tg_ml_smiles("CCO", Tm_K=159.0)
```

## Validation status (what is and is not verified)

Verified against the instrumented Fortran model (AIOMFAC-web v3.14, commit above), full pipeline
(mass/mole fractions -> molalities -> X -> LR -> MR -> SR -> ln gamma -> activities), scaled difference < 1e-12
unless noted:

* **Examples 0001 / 0003** (shipped with the Fortran repo): water + 4 organics + NaCl (12 points, 280-302 K) and a
  carbonate system (1 point; only water and the ions are checked, see below). Neutral gamma also match the values
  printed by the *unmodified* Fortran output routine (6 significant digits).
* **9 generated cases, 145 points** (`tools/make_cases.py`, references regenerated with `tools/run_fortran_cases.sh`):
  NaCl from dilute to near-saturation; CaCl2, MgCl2 (divalent cations); LiCl (high ionic strength); NaCl+KBr (adds the
  cross-combinations NaBr/KCl that are not in the input -- exercises the automatic electrolyte-component completion
  in `build_mixture`); water+ethanol+NaCl with organic and salt varied independently; 4 organics + CaCl2 over a
  275-325 K sweep; a random 6-component mixture with 4 cations / 2 anions (8 electrolyte components, exercises
  cross-ion combinations at once); and dilute/zero-abundance edge points. Together with examples 0001/0003 this
  covers ionic strength from about 1e-6 to > 8 mol/kg and temperatures 275-325 K. Every point also matches the
  *unmodified* Fortran output (6 digits), and all Fortran reference runs finished with error indicator 0 (the only
  non-zero per-point flag anywhere is warning 10, "temperature outside the recommended electrolyte range", expected
  for the two temperature sweeps).
* Parameter tables (SR, subgroup, MR) are bit-identical to the arrays the compiled Fortran model uses.
* **8 more generated cases, 106 points** (`tools/make_cases_ext.py`, references regenerated the same way):
  targeted coverage for gaps identified below. `cc01` (NH4HSO4, 18 points) activates the `Qcca`/`Rcc`
  three-ion interaction terms (confirmed directly: `model._mr.QccaInteract`/`RccInteract` are both `True`, and
  NH4+/H+/HSO4- are all simultaneously present after dissociation) and matches Fortran to the same machine
  precision as every other case. `cc02`/`cc03`/`cc04` (ethyl acetate / dimethyl ether / acetic acid, each +
  NaCl, 10 points) cover the ester (CH3COO), ether (CH3O) and carboxylic-acid (COOH) main groups. `cc05`/`cc06`
  (toluene / methylamine + water, no salt, 16 points each) cover the aromatic-ring and amine main groups --
  electrolyte-free by necessity, since AIOMFAC's MR tables have no main-group<->ion parameters for either
  (Fortran errorflagmix 1; confirmed by the Python port raising the same error for e.g. toluene+NaCl, see
  `test_aromatic_and_amine_main_groups_have_no_electrolyte_mr_parameters`) -- a real limit of the
  parameterization, not a porting gap. `cc07`/`cc08` (PEG oligomer alone, and with (NH4)2SO4, 16 / 10 points)
  cover the PEG subgroup 154 special-case parameters described below. These inputs all set
  `smiles-based pure-component method? 0` (armeliON = `.false.`) so the Fortran run skips the separately-licensed
  TgML_Armeli viscosity/Tg lookup, which is irrelevant to activity coefficients and not installed here (verified:
  byte-identical `debug_terms.txt` with/without it on an existing case).

For **example 0003** specifically: LR and MR of water and of all ions agree to 1e-12 when fed the Fortran molalities
(CO2(aq) is excluded: the Fortran `GammaCO2()` overwrites its LR/MR/SR terms afterwards, not ported).

**Limits of that evidence -- please read before trusting results:**

* No very high ionic strength against Fortran: the `omega*sqrt(I) > 300` and `sqrt(I) > 250` guard branches in
  `mr.py` guard against sqrt(ionic strength) upward of ~250-375 mol/kg -- unreachable by any real electrolyte
  solution (saturated CaCl2/LiCl, the most concentrated cases here, sit around sqrt(I) ~ 4-6) and not
  constructible as an AIOMFAC-web input file, so there is no way to generate a Fortran comparison point either.
  `tests/test_mr_high_ionic_strength.py` calls `mr_terms` directly with a synthetic, deliberately out-of-range
  `si` to confirm the branches execute and return finite output, but "matches Fortran" isn't a meaningful claim
  to make about them.
* **Bisulfate systems** (HSO4- present, or H+ + SO4-- given directly, *without* any HCO3-/CO3--) are now handled
  automatically end-to-end: `ActivityModel` completes the component list with `completion.py` if needed, then
  solves the HSO4- <-> H+ + SO4-- equilibrium (`dissociation.py`, a 1-D root-find with a self-contained Brent's
  method, port of Fortran `HSO4_dissociation`/`DiffKsulfuricDissoc`). Validated against two Fortran cases (NaHSO4;
  H2SO4 given as one H+/SO4-- component) at several concentrations each: equilibrium ion molalities and total
  ln(gamma) of every species agree to atol 1e-12 to 1e-13. Coverage is narrow -- two salts, one temperature
  (298.15 K), no mixed sulfate/other-electrolyte systems, no very high or very low ionic strength -- and the
  root-finder itself is a plain bracket-and-bisect-then-Brent search, not the Fortran solver's guided initial
  guess, so behaviour at pathological edges (near-zero or near-saturation sulfate) is unverified.
* **Bicarbonate-only systems** (HCO3-/CO3--, no sulfate) are now handled automatically too: `ActivityModel`
  completes the system, then solves the 5-unknown equilibrium (CO2(aq) + H2O <-> H+ + HCO3-, HCO3- <-> H+ + CO3--,
  H2O <-> H+ + OH-, plus two mass balances) with `scipy.optimize.root(method="hybr")` -- SciPy's own MINPACK
  `hybrd` wrapper, the same algorithm Fortran uses, rather than a hand-written solver. `GammaCO2` (which overwrites
  CO2(aq)'s own ln(gamma) with a salting-out-coefficient sum) is ported and applied automatically.
  **This one is meaningfully less precise than everything else in this port, and the reason is now well
  understood** (an earlier version of this note wrongly blamed a skipped near-zero-concentration smoothing branch;
  that has been ruled out -- see below). Validated against two Fortran cases (NaHCO3, KHCO3; 2 points each) by
  instrumenting the Fortran source to dump its own converged molar amounts directly (not just the printed
  molalities), so the comparison is apples-to-apples:

  | species | relative difference vs. Fortran |
  |---|---|
  | HCO3- (the dominant carbon species, ~97% of total carbon here) | ~1e-6 |
  | CO3--, CO2(aq) (minor carbon species, ~1-2% each) | ~4e-5 |
  | OH- (trace, ~1e-8 mol/kg) | ~5e-5 |
  | H+ (trace, ~1e-10 mol/kg) | ~3e-4 |

  So the practically important quantities (water activity, the salt's own activity, which are governed by the
  *dominant* species) are accurate to ~1e-6 -- close to the rest of this port. The error is concentrated in the
  *trace* ions H+ and OH-, and the reason is a textbook catastrophic-cancellation problem, not a bug: the
  mass-balance equation that fixes H+ (`n_h_max - n_hco3 - 2*n_co2 - n_oh_max + n_oh = 0`) subtracts terms of
  order 1 from each other to obtain a remainder around 1e-8 -- roughly 8 of the ~16 significant digits of double
  precision are lost in that step. This affects *any* solver working with this formulation, including Fortran's
  own `hybrd`: instrumenting the Fortran source to print its internal constants (`nHmax`, `nCarbmax`, `nOHmax`,
  etc.) confirmed they are computed identically to this port's values (bit-for-bit, up to the last 1-2 digits), and
  seeding this port's solver with Fortran's own converged answer causes it to visibly move *away* from that answer
  to a different point where the equations (as coded, matching Fortran's source line-for-line) are satisfied to
  machine precision (residual ~1e-14) -- i.e., both solvers are finding genuine, self-consistent roots of an
  ill-conditioned system, and the small disagreement between them for the trace species is inherent to that
  conditioning rather than a fixable defect. An attempt to sidestep this for H+ specifically, by recomputing it
  from the (well-conditioned, purely multiplicative) Kw equilibrium instead of the mass balance, reproduced the
  same value -- unsurprising in hindsight, since Kw is already satisfied by the converged solution to the same
  ~1e-14 residual, so that recomputation is circular and adds no information.
  Requires the optional `scipy` dependency (`pip install aiomfac_py[carbonate]`); `ActivityModel` raises
  `ImportError` from within `carbonate.solve_carbonate` if it is used without scipy installed.
* **Bisulfate + bicarbonate systems together** (both HSO4-/SO4-- and HCO3-/CO3--) are now handled automatically
  too: `ActivityModel` solves the joint 6-unknown equilibrium (`carbonate.solve_carb_sulf`, port of Fortran
  `HSO4_and_HCO3_dissociation` with `bisulfsyst == True`) -- the same three bicarbonate equilibria as above plus
  HSO4- <-> H+ + SO4--, all coupled through the shared H+ pool. If Ca2+ is also present, the deterministic
  Ca2+ + SO4-- -> CaSO4(s) precipitation pre-step (`_precipitate_ca_sulfate`, Fortran's `idCa > 0` branch -- a
  full stoichiometric removal down to a tiny bookkeeping residual, *not* a Ksp-based solubility equilibrium; the
  original Fortran routine doesn't model one either) runs first.

  Validated against two Fortran cases instrumented the same way as the bicarbonate-only solver above: `c005`
  (Water + NaHSO4 + NaHCO3, no Ca2+, 10 points across dilute/concentrated/trace-species compositions and three
  temperatures) and `c006` (Water + Ca(IO3)2 + NaHSO4 + NaHCO3, 6 points, exercising the precipitation step; the
  divalent anion component uses AIOMFAC subgroup 246, IO3-, not Cl- -- an earlier draft of this case mislabeled it
  "CaCl2"; the underlying Ca2+/CaSO4(s) precipitation math is anion-independent, so this was a labeling error only,
  not a validation error).
  Agreement is **machine precision (~1e-14 to 1e-15) at every point where Fortran's own solver converges** --
  markedly *better* than the bicarbonate-only case, because here H+ is pinned by two independent equilibria
  (bisulfate and bicarbonate) rather than one, which sidesteps the catastrophic-cancellation conditioning issue
  documented above.

  One edge case is worth calling out explicitly: when Ca2+ is present in *large excess* of the total sulfate pool,
  Fortran's precipitation step consumes essentially all of the sulfate, leaving a residual SO4-- pool pinned at a
  ~1e-13 mol bookkeeping floor (`min(1e-5*nSulfmax, 1e3*deps)` -- for any normal-sized system this evaluates to
  the `deps`-scaled term, not the `nSulfmax`-scaled one). Solving the coupled 6-unknown system with this one
  equation living ~13 orders of magnitude below the other five is numerically degenerate -- and this was verified
  to be a limitation of Fortran's own `hybrd` solve, not an artifact of this port: instrumenting the two
  problematic input points directly showed MINPACK returning `info == 4` ("iteration is not making good
  progress") with `sum(|diffK|) ~ 38` instead of ~1e-13, i.e. Fortran's own reported output for these inputs is
  not a converged, trustworthy equilibrium either. In that regime, this port decouples the negligible sulfate
  equilibrium (fixing HSO4- ~ 0, since a pool this small dissociates essentially completely) and solves the
  remaining bicarbonate system with the already-validated `solve_carbonate`, giving a well-converged,
  mass-balanced answer of its own rather than attempting to reproduce Fortran's non-convergent one. This
  decoupling is not expected to -- and, by construction, does not -- bit-match Fortran's unreliable output for
  such inputs; `tests/test_carb_sulf.py` documents and tests this explicitly rather than silently working around
  it.
* **PEG systems (subgroup 154, "CH2OCH2[PEG]") are now ported**: `system.py` overrides R/Q of subgroup 154 in the
  SR combinatorial term (this turns out to be a no-op against the *current* parameter tables -- the tabulated
  Bondi values already equal the "special" ones -- but is kept for parity with the Fortran source and in case a
  future table regeneration changes that), and `mr.py` overrides the CHn[OH,PEG] main group (52/68) <-> NH4+/SO4--
  MR interaction coefficients (a real, active override). Validated against two Fortran cases (`cc07`/`cc08` in
  `tests/reference/ext/`, a PEG oligomer alone and with (NH4)2SO4) to the same ~1e-14 precision as every other
  case. The viscosity-only `isPEGsystem` special cases (`XieR`/`XieC`, gated by `calcviscosity`) remain out of
  scope, like the rest of AIOMFAC-VISC.
* **Not ported, and confirmed unreachable through any AIOMFAC-web input file, so not worth porting**: the
  3-parameter temperature dependence (BRR/CRR, `case(500:800, 2000:2434)` in `ModSRunifac.f90`) is gated on a
  Fortran variable `nd` ("dataset number") that the web driver hardcodes to `1` at its single call site
  (`SubModDefSystem.f90`: `call SetSystem(1, ...)`, with the comment "nd = 1 for web-version"); the 500-800/2000-
  2434 branch exists only for the AIOMFAC team's own internal parameter-fitting runs against numbered literature
  datasets, never for a user-supplied input file. Likewise `solvmixrefnd` (solvent-mixture reference state) is
  never set `.true.` anywhere in the Fortran source, and `SpecialInputConcConversion` is dataset-number-keyed
  input-conversion logic for the same internal fitting mode (the web version always takes its `defaultcase`
  path). All three are genuinely dead code from this port's perspective, not gaps.
* Tmolal in example 0003 differs from the dump by ~1e-8 because the Fortran value comes from a different iterate of
  its dissociation loop; expected until the dissociation equilibria are ported.
* **`aiomfac_py.s2as`** (SMILES -> AIOMFAC subgroups): the matching algorithm is vendored from upstream S2AS
  essentially verbatim (see the subpackage's module docstring for the exact, deliberate integration-level
  differences: no blocking `input()` prompt and no uncaught `IndigoException` on invalid SMILES). Validated
  bit-for-bit against upstream's own three example cases (7, 174, and 2823 molecules, `tests/reference/s2as/`,
  generated by actually running the upstream script and comparing every component's subgroup decomposition) --
  0 mismatches across all 3004 molecules combined. Requires the optional `epam.indigo` dependency
  (`pip install aiomfac_py[smiles]`); raises `ImportError` with a clear message if it is not installed, and is
  never imported by `aiomfac_py`'s own top-level package.
